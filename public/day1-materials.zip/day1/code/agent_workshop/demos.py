from __future__ import annotations

import json
from pathlib import Path
from .api import SchoolModel, ModelError
from .config import ROOT, Settings
from .knowledge import search_events, search_policy
from .loop import SYSTEM, run_agent
from .memory import ProfileStore
from .mock_model import TeachingModel, RepeatingModel
from .tools import LocalTools
from .trace import Trace

DEMOS = {
    'D01': ('같은 질문, 모델 단독과 조회 도구 비교', 3),
    'D02': ('행사 비서의 실행 기록', 5),
    'D03': ('학교 API 최소 호출', 7),
    'D04': ('지시문 변경 전후 비교', 9),
    'D05': ('도구 요청과 실제 함수 실행', 11),
    'D06': ('목록 조회 다음 상세 조회', 13),
    'D07': ('결과 없음과 단계 제한', 15),
    'D08': ('MCP 서버 도구 목록', 18),
    'D09': ('MCP 도구 실제 실행', 20),
    'D10': ('규정 문단 검색', 22),
    'D11': ('검색 문단을 넣어 답변 생성', 24),
    'D12': ('대화 기록을 비우기', 26),
    'D13': ('프로필 저장과 새 대화', 28),
    'D14': ('선호와 규정의 통합', 30),
}


def messages(question: str, context: str = '', system: str = SYSTEM) -> list[dict]:
    result = [{'role': 'system', 'content': system}]
    if context:
        result.append({'role': 'system', 'content': context})
    result.append({'role': 'user', 'content': question})
    return result


async def plain(model, history: list[dict], trace: Trace, label: str = '모델 호출') -> str:
    trace.add('model_input', label + ' 입력', history)
    try:
        output = await model.chat(history)
    except ModelError as exc:
        trace.add('error', label + ' 실패', str(exc))
        raise
    trace.add('model_output', label + ' 출력', output)
    answer = output['message'].get('content') or ''
    trace.add('answer', label + ' 답변', answer)
    return answer


async def run_demo(demo_id: str, mode: str = 'mock', state_dir: Path | None = None,
                   settings: Settings | None = None) -> Trace:
    if demo_id not in DEMOS or mode not in ('mock', 'live'):
        raise ValueError('알 수 없는 시연 번호 또는 실행 모드입니다.')
    trace = Trace(mode, demo_id)
    trace.add('intro', DEMOS[demo_id][0], {'slide': DEMOS[demo_id][1], 'fixture': '수업용 가상 데이터'})
    model = TeachingModel() if mode == 'mock' else SchoolModel(settings or Settings.from_env())
    base = 'Python 입문자가 들을 만한 동아리 행사를 추천해줘.'
    detail = 'Python 관련 행사를 찾고, 후보의 상세 내용을 확인해서 입문자에게 맞는 온라인 행사 하나를 추천해줘.'
    policy_question = '나는 1학년이고 Python을 처음 배우는데, E-102 행사에 신청할 수 있어? 근거도 알려줘.'
    tools = LocalTools(('search_events', 'get_event'))

    if demo_id == 'D01':
        same_question = '등록된 Python 행사 목록을 알려줘.'
        await plain(model, messages(same_question), trace, '도구 없는 모델')
        await run_agent(model, LocalTools(('search_events',)), messages(same_question), trace)
    elif demo_id == 'D02':
        await run_agent(model, tools, messages(detail), trace)
    elif demo_id == 'D03':
        await plain(model, messages(base), trace)
    elif demo_id == 'D04':
        await plain(model, messages(base), trace, '기존 지시문')
        await plain(model, messages(base, system=SYSTEM + '\n추천 방향, 확인할 정보, 다음 행동을 3줄로 작성한다.'), trace, '수정 지시문')
    elif demo_id == 'D05':
        trace.add('direct_tool', '모델 없이 Python 함수 직접 실행', search_events('Python'))
        await run_agent(model, LocalTools(('search_events',)), messages('등록된 Python 행사 목록을 알려줘.'), trace)
    elif demo_id == 'D06':
        await run_agent(model, tools, messages(detail), trace)
    elif demo_id == 'D07':
        await run_agent(model, tools, messages('양자물리 행사를 찾아줘.'), trace)
        trace.add('notice', '고장 주입 예시', '이 구간은 live 모드에서도 모의 모델을 사용해 반복과 단계 제한을 재현합니다.')
        await run_agent(RepeatingModel(), tools, messages('Python 행사를 계속 찾아줘.'), trace, max_steps=2)
        trace.add('validation', '잘못된 인자를 모델 호출 없이 검증', await tools.execute('get_event', {'event_id': 123}))
    elif demo_id in ('D08', 'D09'):
        from .mcp_bridge import connect_mcp
        async with connect_mcp(trace) as remote_tools:
            if demo_id == 'D08':
                trace.add('checkpoint', '여기서 설명으로 돌아갑니다', 'tools/list까지만 확인했습니다. 도구 실행은 D09에서 이어집니다.')
            else:
                await run_agent(model, remote_tools, messages('지금 등록된 Python 행사 목록을 알려줘.'), trace)
    elif demo_id == 'D10':
        retrieval = search_policy('E-102 신청 자격')
        trace.add('retrieval', '키워드 검색 결과', retrieval)
        trace.add('checkpoint', '여기서 설명으로 돌아갑니다', '이 결과를 모델 입력에 넣는 위치를 설명한 뒤 D11을 실행합니다.')
    elif demo_id == 'D11':
        await plain(model, messages(policy_question), trace, '규정 제공 전')
        retrieval = search_policy('E-102 신청 자격')
        trace.add('retrieval', 'D10과 같은 검색 결과', retrieval)
        context = '<retrieved_context>' + json.dumps(retrieval, ensure_ascii=False) + '</retrieved_context>'
        await plain(model, messages(policy_question, context), trace, '규정 제공 후')
        absent = search_policy('주차 할인')
        trace.add('retrieval', '자료에 없는 질문의 검색 결과', absent)
        await plain(model, messages('주차 할인을 받을 수 있어?', '<retrieved_context>' + json.dumps(absent) + '</retrieved_context>'), trace, '근거 없음')
    elif demo_id == 'D12':
        history = [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': '나는 온라인 행사를 선호해.'},
                   {'role': 'assistant', 'content': '이번 대화에서 참고하겠습니다.'},
                   {'role': 'user', 'content': '내가 어떤 참가 방식을 선호했지?'}]
        await plain(model, history, trace, '대화 기록 포함')
        await plain(model, messages('내가 어떤 참가 방식을 선호했지?'), trace, '대화 기록 초기화')
    elif demo_id in ('D13', 'D14'):
        store = ProfileStore(state_dir or ROOT / 'state')
        # 강사가 시연하는 가상 사용자만 초기화합니다. 다른 사용자 파일은 건드리지 않습니다.
        user = 'demo_' + demo_id.lower()
        store.forget(user)
        trace.add('memory_request', '명시적 저장 요청', '나는 1학년이고 온라인 행사를 선호해. 다음에도 기억해줘.')
        trace.add('memory_write', '프로그램이 명시적으로 저장한 프로필', store.update(user, {'grade': 1, 'preferred_mode': 'online'}))
        trace.add('notice', '저장 방식', '이 입문 예제는 명시적 선택값을 앱에서 저장합니다. 자유 문장의 자동 정보 추출은 구현하지 않습니다.')
        fresh_store = ProfileStore(store.directory)
        trace.add('memory_read', '새 대화에서 파일을 다시 읽음', fresh_store.get(user))
        question = ('나에게 맞는 Python 입문 행사 하나를 찾고, 신청 가능한지 규정 근거와 함께 알려줘.'
                    if demo_id == 'D14' else '나에게 맞는 Python 입문 행사 하나를 추천해줘.')
        await run_agent(model, LocalTools() if demo_id == 'D14' else tools,
                        messages(question, fresh_store.context(user)), trace)
        if demo_id == 'D13':
            await run_agent(model, tools, messages('이번에는 대면 Python 입문 행사로 찾아줘.', fresh_store.context(user)), trace)
            trace.add('memory_read', '일회성 요청 뒤 장기 선호 확인', fresh_store.get(user))
    return trace
