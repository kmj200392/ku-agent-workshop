from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]


def load_env(path: Path | None = None) -> None:
    """이 프로젝트의 .env만 읽습니다. 기존 환경변수를 덮어쓰지 않습니다."""
    path = path or ROOT / '.env'
    if not path.exists():
        return
    for raw in path.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name, value = line.split('=', 1)
        name, value = name.strip(), value.strip()
        if name.startswith('KU_'):
            os.environ.setdefault(name, value.strip('\"\''))


@dataclass
class Settings:
    api_key: str = ''
    model: str = ''
    base_url: str = 'https://api.baze.co/v1/gateway'
    timeout: float = 40
    max_output_tokens: int = 900
    token_parameter: str = 'max_tokens'

    @classmethod
    def from_env(cls) -> 'Settings':
        load_env()
        return cls(
            api_key=os.getenv('KU_API_KEY', ''), model=os.getenv('KU_MODEL', ''),
            base_url=os.getenv('KU_BASE_URL', cls.base_url).rstrip('/'),
            timeout=float(os.getenv('KU_TIMEOUT', '40')),
            max_output_tokens=int(os.getenv('KU_MAX_OUTPUT_TOKENS', '900')),
            token_parameter=os.getenv('KU_TOKEN_PARAMETER', 'max_tokens'),
        )

    def validate(self, need_model: bool = True) -> None:
        if not self.api_key:
            raise ValueError('KU_API_KEY가 없습니다. .env.example을 .env로 복사하고 개인 키를 설정하세요.')
        if need_model and not self.model:
            raise ValueError('KU_MODEL이 없습니다. 학교 개발자 화면 또는 --list-models로 모델 ID를 확인하세요.')
        url = urlparse(self.base_url)
        if url.scheme != 'https' and url.hostname not in ('localhost', '127.0.0.1'):
            raise ValueError('API 키 전송에는 HTTPS가 필요합니다.')
        if self.token_parameter not in ('max_tokens', 'max_completion_tokens'):
            raise ValueError('KU_TOKEN_PARAMETER는 max_tokens 또는 max_completion_tokens입니다.')
        if not 1 <= self.timeout <= 120 or not 1 <= self.max_output_tokens <= 32768:
            raise ValueError('timeout은 1~120초, 출력 토큰 한도는 1~32768이어야 합니다.')
