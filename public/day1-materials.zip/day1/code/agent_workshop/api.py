from __future__ import annotations

import asyncio
import json
import socket
import urllib.error
import urllib.request
from .config import Settings


class ModelError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # 실수로 다른 호스트에 키를 보내지 않도록 리다이렉트는 자동 추적하지 않습니다.
        return None


class SchoolModel:
    """OpenAI 호환 Chat Completions HTTP. 키는 요청 헤더에만 사용합니다."""
    mode = 'live'

    def __init__(self, settings: Settings):
        self.settings = settings

    def _request(self, route: str, payload: dict | None = None) -> dict:
        self.settings.validate(need_model=payload is not None)
        body = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else None
        request = urllib.request.Request(self.settings.base_url.rstrip('/') + '/' + route.lstrip('/'),
            data=body, headers={'Authorization': 'Bearer ' + self.settings.api_key,
                                'Content-Type': 'application/json'}, method='POST' if body else 'GET')
        try:
            with urllib.request.build_opener(NoRedirect).open(request, timeout=self.settings.timeout) as response:
                data = json.load(response)
                if not isinstance(data, dict):
                    raise ModelError('API 응답이 JSON object가 아닙니다.')
                return data
        except urllib.error.HTTPError as exc:
            tips = {401: '키를 확인하세요.', 403: '모델·계정 권한을 확인하세요.',
                    402: '크레딧을 확인하세요.', 404: 'Base URL과 모델 ID를 확인하세요.',
                    429: '호출 제한 또는 크레딧을 확인하고 잠시 뒤 다시 실행하세요.',
                    400: '모델의 tools·출력 토큰 파라미터 지원을 확인하세요.'}
            raise ModelError(f'HTTP {exc.code}: {tips.get(exc.code, "서비스 응답을 확인하세요.")} 자동 재시도하지 않았습니다.') from None
        except (urllib.error.URLError, TimeoutError, socket.timeout):
            raise ModelError('네트워크 연결 또는 응답 시간 초과입니다. 모의 모드로 전환하거나 나중에 다시 실행하세요.') from None
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ModelError('API 응답을 JSON으로 읽을 수 없습니다.') from None

    async def list_models(self) -> dict:
        return await asyncio.to_thread(self._request, 'models/')

    async def chat(self, messages: list[dict], tools: list[dict] | None = None) -> dict:
        payload = {'model': self.settings.model, 'messages': messages,
                   self.settings.token_parameter: self.settings.max_output_tokens, 'stream': False}
        if tools:
            payload.update(tools=tools, tool_choice='auto')
        data = await asyncio.to_thread(self._request, 'chat/completions/', payload)
        try:
            choice = data['choices'][0]
            message = choice['message']
            if not isinstance(message, dict):
                raise TypeError
            if choice.get('finish_reason') in ('length', 'content_filter'):
                raise ModelError('응답이 토큰 한도 또는 필터로 중단됐습니다. 불완전한 결과는 실행하지 않습니다.')
            if not message.get('content') and not message.get('tool_calls'):
                raise ModelError('텍스트와 도구 요청이 모두 비어 있습니다.')
            return {'message': {k: message[k] for k in ('role', 'content', 'tool_calls') if k in message},
                    'usage': data.get('usage', {}), 'model': data.get('model', self.settings.model)}
        except (KeyError, IndexError, TypeError):
            raise ModelError('Chat Completions 응답 형식이 예상과 다릅니다.') from None
