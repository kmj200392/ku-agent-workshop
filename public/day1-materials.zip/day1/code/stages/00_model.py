"""D03–D04: 여기서는 지시문과 사용자 요청을 바꿔보세요."""
import asyncio
from _setup import setup
from agent_workshop.demos import plain


async def main():
    model, trace = setup('00_model')
    messages = [
        {'role': 'system', 'content': '한국어로 답하고 확인하지 못한 정보는 모른다고 말한다.'},
        {'role': 'user', 'content': 'Python 입문자가 들을 만한 행사를 추천해줘.'},
    ]
    await plain(model, messages, trace)
    trace.print()


asyncio.run(main())
