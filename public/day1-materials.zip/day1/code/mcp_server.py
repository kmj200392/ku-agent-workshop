"""수업용 실제 MCP stdio 서버. stdout에는 프로토콜만 출력합니다."""
from mcp.server.fastmcp import FastMCP
from agent_workshop.knowledge import search_events as search, get_event as detail

server = FastMCP('Workshop Event Tools')


@server.tool()
def search_events(query: str) -> dict:
    """가상 행사 제목·태그를 검색한다. 상세 조건은 get_event로 조회한다."""
    return search(query)


@server.tool()
def get_event(event_id: str) -> dict:
    """가상 행사 ID로 일정, 참가 형태, 난이도, 학년 조건을 조회한다."""
    return detail(event_id)


if __name__ == '__main__':
    server.run(transport='stdio')
