"""D06–D07: 공통 루프 구현은 agent_workshop/loop.py에 있습니다."""
import asyncio
from _setup import setup
from agent_workshop.demos import messages
from agent_workshop.tools import LocalTools
from agent_workshop.loop import run_agent


async def main():
    model, trace = setup('02_agent_loop')
    request = 'Python 행사 후보의 상세를 확인해 입문자에게 맞는 온라인 행사를 추천해줘.'
    await run_agent(model, LocalTools(('search_events', 'get_event')),
                    messages(request), trace, max_steps=6, max_tool_calls=8)
    trace.print()


asyncio.run(main())
