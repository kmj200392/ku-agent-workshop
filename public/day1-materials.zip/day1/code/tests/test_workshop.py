from __future__ import annotations

import asyncio
import contextlib
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from agent_workshop.api import SchoolModel, ModelError
from agent_workshop.config import Settings
from agent_workshop.demos import run_demo, messages
from agent_workshop.knowledge import search_policy, get_event
from agent_workshop.loop import run_agent
from agent_workshop.memory import ProfileStore
from agent_workshop.mock_model import TeachingModel, RepeatingModel
from agent_workshop.tools import LocalTools
from agent_workshop.trace import Trace


class KnowledgeMemoryTests(unittest.TestCase):
    def test_search_returns_relevant_source_and_unknown_is_empty(self):
        result = search_policy('E-102 신청 자격')
        self.assertEqual(result['matches'][0]['source'], 'admission.md#1')
        self.assertIn('1~4학년', result['matches'][0]['text'])
        self.assertEqual(search_policy('주차 할인')['matches'], [])

    def test_memory_persists_across_instances_and_isolates_users(self):
        with tempfile.TemporaryDirectory() as directory:
            store = ProfileStore(Path(directory))
            store.update('alice', {'preferred_mode': 'online', 'grade': 1})
            reread = ProfileStore(Path(directory))
            self.assertEqual(reread.get('alice')['preferred_mode'], 'online')
            self.assertEqual(reread.get('bob'), {})
            with self.assertRaises(ValueError): reread.get('../alice')
            with self.assertRaises(ValueError): reread.update('alice', {'grade': True})
            reread.forget('alice')
            self.assertEqual(reread.get('alice'), {})


class AgentTests(unittest.IsolatedAsyncioTestCase):
    async def test_tool_args_and_allowlist(self):
        tools = LocalTools()
        self.assertEqual((await tools.execute('shell', {'command': 'pwd'}))['error'], 'unknown_tool')
        self.assertEqual((await tools.execute('get_event', {'event_id': 7}))['error'], 'invalid_arguments')
        self.assertEqual((await tools.execute('search_policy', {'query': 'Python', 'limit': True}))['error'], 'invalid_arguments')
        self.assertEqual((await tools.execute('get_event', {'event_id': 'E-102', 'extra': 1}))['error'], 'invalid_arguments')

    async def test_loop_uses_observations_and_completes(self):
        trace = Trace('mock', 'test')
        result = await run_agent(TeachingModel(), LocalTools(), messages('입문자에게 맞는 온라인 Python 행사를 상세 조회해서 추천해줘.'), trace)
        self.assertEqual(result.stop_reason, 'completed')
        self.assertIn('E-102', result.answer)
        tool_names = [e['data']['name'] for e in trace.events if e['kind'] == 'tool_result']
        self.assertEqual(tool_names, ['search_events', 'get_event', 'get_event'])
        self.assertEqual(len([m for m in result.messages if m['role'] == 'tool']), 3)

    async def test_step_and_tool_limits_are_enforced(self):
        trace = Trace('mock', 'limit')
        result = await run_agent(RepeatingModel(), LocalTools(), messages('계속 조회'), trace, max_steps=2)
        self.assertEqual((result.stop_reason, result.model_calls, result.tool_calls), ('max_steps', 2, 2))
        result = await run_agent(RepeatingModel(), LocalTools(), messages('계속 조회'), trace, max_tool_calls=1)
        self.assertEqual((result.stop_reason, result.tool_calls), ('tool_budget', 1))

    async def test_invalid_json_becomes_tool_error_not_execution(self):
        class Broken(TeachingModel):
            async def chat(self, history, tools=None):
                if history[-1]['role'] == 'tool':
                    return self._answer('입력 오류를 확인했습니다.')
                result = self._call('get_event', event_id='E-102')
                result['message']['tool_calls'][0]['function']['arguments'] = '{broken'
                return result
        trace = Trace('mock', 'broken')
        result = await run_agent(Broken(), LocalTools(), messages('상세 조회'), trace)
        self.assertEqual(result.stop_reason, 'completed')
        error = next(e['data']['result'] for e in trace.events if e['kind'] == 'tool_result')
        self.assertEqual(error['error'], 'invalid_arguments')

    async def test_duplicate_call_id_stops_before_second_execution(self):
        class Duplicate(TeachingModel):
            async def chat(self, history, tools=None):
                result = self._call('get_event', event_id='E-102')
                result['message']['tool_calls'][0]['id'] = 'same_id'
                return result
        result = await run_agent(Duplicate(), LocalTools(), messages('상세 조회'), Trace('mock', 'dupe'))
        self.assertEqual(result.stop_reason, 'invalid_response')
        self.assertEqual(result.tool_calls, 1)

    async def test_tool_timeout_is_returned_to_model(self):
        class Slow(LocalTools):
            async def execute(self, name, arguments):
                await asyncio.sleep(.1)
                return {}
        trace = Trace('mock', 'timeout')
        result = await run_agent(TeachingModel(), Slow(), messages('Python 행사'), trace, tool_timeout=.001)
        self.assertEqual(result.stop_reason, 'completed')
        self.assertTrue(any(e['kind'] == 'tool_result' and e['data']['result'].get('error') == 'tool_timeout' for e in trace.events))

    async def test_all_demos_and_mcp_protocol(self):
        with tempfile.TemporaryDirectory() as directory:
            traces = {}
            for number in range(1,15):
                demo = f'D{number:02}'
                traces[demo] = await run_demo(demo, 'mock', Path(directory))
                self.assertGreater(len(traces[demo].events), 1)
                self.assertFalse(any(e['kind'] == 'stop' and e['data']['reason'] in ('invalid_response','model_error') for e in traces[demo].events), demo)
            self.assertTrue(any(e['kind'] == 'mcp' for e in traces['D08'].events))
            self.assertTrue(any(e['kind'] == 'tool_result' and e['data']['result'].get('count') == 4 for e in traces['D09'].events))
            answers = [e['data'] for e in traces['D13'].events if e['kind'] == 'answer']
            self.assertIn('E-102', answers[0]); self.assertIn('E-103', answers[1])
            self.assertEqual(ProfileStore(Path(directory)).get('demo_d13')['preferred_mode'], 'online')
            final = [e['data'] for e in traces['D14'].events if e['kind'] == 'answer'][-1]
            self.assertIn('admission.md#1', final); self.assertIn('E-102', final)


class GatewayContractTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.requests = []
        self.status = 200
        self.finish = 'stop'
        owner = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                owner.requests.append((self.path, dict(self.headers), body))
                self.send_response(owner.status); self.send_header('Content-Type', 'application/json'); self.end_headers()
                self.wfile.write(json.dumps({'choices': [{'finish_reason': owner.finish, 'message': {'role': 'assistant', 'content': '확인'}}]}).encode())
        self.server = HTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.model = SchoolModel(Settings(api_key='test-only-secret', model='test-model', base_url=f'http://127.0.0.1:{self.server.server_port}/v1/gateway'))

    async def asyncTearDown(self):
        await asyncio.to_thread(self.server.shutdown)
        self.server.server_close()
        self.thread.join()

    async def test_gateway_request_contract(self):
        result = await self.model.chat(messages('확인'), LocalTools().definitions)
        path, headers, body = self.requests[0]
        self.assertEqual(path, '/v1/gateway/chat/completions/')
        self.assertEqual(headers['Authorization'], 'Bearer test-only-secret')
        self.assertEqual(body['model'], 'test-model')
        self.assertFalse(body['stream']); self.assertEqual(body['tool_choice'], 'auto')
        self.assertEqual(result['message']['content'], '확인')

    async def test_error_no_retry_and_no_key_leak(self):
        self.status = 429
        with self.assertRaises(ModelError) as raised:
            await self.model.chat(messages('실패'))
        self.assertIn('429', str(raised.exception))
        self.assertNotIn('test-only-secret', str(raised.exception))
        self.assertEqual(len(self.requests), 1)

    async def test_incomplete_output_rejected(self):
        self.finish = 'length'
        with self.assertRaises(ModelError):
            await self.model.chat(messages('길이 제한'))


if __name__ == '__main__':
    unittest.main()
