from __future__ import annotations

import json
import re


class TeachingModel:
    """교육용 모의 모델입니다. 아래 규칙은 학습된 모델이나 LLM 추론이 아닙니다.

    실시간 API 장애에도 도구·루프·검색·메모리 코드를 실행할 수 있게 만든 예제입니다.
    자유로운 프롬프트 실험과 실제 모델 성능 확인에는 live 모드를 사용하세요.
    """
    mode = 'mock'

    def __init__(self):
        self.serial = 0

    def _answer(self, text: str) -> dict:
        return {'message': {'role': 'assistant', 'content': text}, 'model': 'teaching-rules (not LLM)', 'usage': {}}

    def _call(self, name: str, **arguments) -> dict:
        self.serial += 1
        return {'message': {'role': 'assistant', 'content': None,
                'tool_calls': [{'id': f'example_{self.serial}', 'type': 'function',
                                'function': {'name': name, 'arguments': json.dumps(arguments, ensure_ascii=False)}}]},
                'model': 'teaching-rules (not LLM)', 'usage': {}}

    async def chat(self, messages: list[dict], tools: list[dict] | None = None) -> dict:
        users = [m.get('content', '') for m in messages if m.get('role') == 'user']
        question = users[-1] if users else ''
        context = '\n'.join(str(m.get('content', '')) for m in messages if m.get('role') != 'tool')
        explicit_offline = '대면' in question
        mode = 'offline' if explicit_offline else ('online' if ('온라인' in question or '"preferred_mode": "online"' in context) else None)
        grade = 1 if '1학년' in context or '"grade": 1' in context else None
        allowed = {t['function']['name'] for t in (tools or [])}
        if not allowed:
            found = re.search(r'<retrieved_context>(.*?)</retrieved_context>', context, re.S)
            if found:
                retrieval = json.loads(found.group(1))
                matches = retrieval.get('matches', [])
                if not matches:
                    return self._answer('제공한 자료에서 근거를 찾지 못했습니다. 운영진 확인이 필요합니다.')
                eligibility = next((m for m in matches if m['source'] == 'admission.md#1'), None)
                if eligibility and 'E-102' in question:
                    return self._answer('1학년이며 Python을 처음 배워도 E-102에 신청할 수 있습니다. '
                                        '1~4학년과 사전 경험이 없는 학생을 허용합니다. [admission.md#1]\n신청은 별도 페이지에서 진행해야 합니다.')
                return self._answer('검색한 규정의 근거:\n' + '\n'.join(f'[{m["source"]}] {m["text"]}' for m in matches))
            if '선호' in question:
                if explicit_offline:
                    return self._answer('이번 요청에서는 대면 행사를 우선하겠습니다. 저장된 장기 선호는 그대로 둡니다.')
                if mode == 'online' or any('온라인' in u for u in users[:-1]):
                    return self._answer('전달된 대화 또는 프로필에서 온라인 선호를 확인했습니다.')
                return self._answer('현재 입력에는 선호 정보가 없습니다. 온라인과 대면 중 어느 쪽을 선호하나요?')
            if '3줄' in context:
                return self._answer('추천 방향: Python 입문 행사\n확인 필요: 실제 등록 행사와 참가 조건\n다음 단계: 행사 데이터를 조회하기')
            return self._answer('Python 입문 행사가 적합할 수 있습니다. 현재 입력에는 실제 등록 행사 목록이 없어 특정 행사 이름과 일정을 확인할 수 없습니다.')

        # 이번 사용자 요청 뒤에 나온 실제 도구 결과만 사용합니다.
        start = max((i for i, m in enumerate(messages) if m.get('role') == 'user'), default=-1)
        results = []
        for message in messages[start + 1:]:
            if message.get('role') == 'tool':
                results.append(json.loads(message['content']))
        listing = next((r for r in results if 'events' in r), None)
        details = [r for r in results if 'id' in r and 'mode' in r]
        policy = next((r for r in results if 'matches' in r), None)
        if any('error' in r for r in results):
            return self._answer('도구에서 오류를 반환했습니다. 해당 정보는 확인하지 못했으며 요청을 완료하지 않았습니다.')
        explicit_id = re.search(r'E-\d{3}', question)
        if explicit_id and 'get_event' in allowed and not details:
            return self._call('get_event', event_id=explicit_id.group())
        if listing is None and not details and 'search_events' in allowed:
            query = '양자물리' if '양자물리' in question else ('JavaScript' if 'JavaScript' in question else 'Python')
            return self._call('search_events', query=query)
        if listing is not None and not listing['events']:
            return self._answer('등록된 행사에서 해당 검색어를 찾지 못했습니다. 다른 주제로 찾아볼까요?')
        if listing is not None and ('목록' in question or 'get_event' not in allowed):
            return self._answer('\n'.join(f'{e["id"]}: {e["title"]}' for e in listing['events']))
        suitable = [e for e in details if (mode is None or e['mode'] == mode)
                    and (grade is None or grade in e['grades'])
                    and (not any(w in question for w in ('입문', '처음', '초보')) or e['level'] == 'beginner')]
        if not suitable and listing is not None and 'get_event' in allowed:
            seen = {e['id'] for e in details}
            candidate = next((e for e in listing['events'] if e['id'] not in seen), None)
            if candidate:
                return self._call('get_event', event_id=candidate['id'])
        if not suitable:
            return self._answer('조회한 행사에서 요청한 조건을 충족하는 대상을 확인하지 못했습니다.')
        chosen = suitable[0]
        needs_policy = any(word in question for word in ('규정', '신청', '자격', '근거'))
        if needs_policy and policy is None and 'search_policy' in allowed:
            return self._call('search_policy', query=chosen['id'] + ' 신청 자격', limit=3)
        result = f'{chosen["id"]} {chosen["title"]}을 추천합니다. {chosen["date"]} {chosen["time"]}, '
        result += ('온라인' if chosen['mode'] == 'online' else '대면') + ' 행사입니다.'
        if needs_policy:
            if not policy or not policy['matches']:
                result += '\n신청 자격의 문서 근거는 확인하지 못했습니다.'
            else:
                source = next((m for m in policy['matches'] if m['source'].startswith('admission.md')), policy['matches'][0])
                result += f'\n{source["text"]} [{source["source"]}]\n신청은 별도로 진행해야 합니다.'
        return self._answer(result)


class RepeatingModel(TeachingModel):
    """단계 제한 검증용 고장 주입. live 모드에서도 이 작은 사례만 모의 실행합니다."""
    async def chat(self, messages, tools=None):
        return self._call('search_events', query='Python')
