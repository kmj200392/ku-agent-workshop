"""D10–D11: 먼저 검색하고 검색 결과를 모델의 입력에 넣습니다."""
import asyncio
import json
from _setup import setup
from agent_workshop.demos import messages, plain
from agent_workshop.knowledge import search_policy


async def main():
    model, trace = setup('04_rag')
    question = '1학년이고 Python을 처음 배우는데 E-102에 신청할 수 있어?'
    retrieval = search_policy('E-102 신청 자격')
    trace.add('retrieval', '관련 문서 검색', retrieval)
    context = '<retrieved_context>' + json.dumps(retrieval, ensure_ascii=False) + '</retrieved_context>'
    await plain(model, messages(question, context), trace)
    trace.print()


asyncio.run(main())
