from __future__ import annotations

import json
import os
import re
import tempfile
from pathlib import Path


class ProfileStore:
    """실습용 사용자별 JSON 저장소. 서비스용 동시성·인증 계층은 별도 필요합니다."""
    def __init__(self, directory: Path):
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=True)

    def _path(self, user_id: str) -> Path:
        if not re.fullmatch(r'[a-zA-Z0-9_-]{1,40}', user_id):
            raise ValueError('사용자 ID는 영문·숫자·밑줄·하이픈 1~40자입니다.')
        return self.directory / f'{user_id}.json'

    def get(self, user_id: str) -> dict:
        path = self._path(user_id)
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}

    def update(self, user_id: str, fields: dict) -> dict:
        if set(fields) - {'preferred_mode', 'grade'}:
            raise ValueError('허용한 프로필 필드만 저장할 수 있습니다.')
        if 'preferred_mode' in fields and fields['preferred_mode'] not in ('online', 'offline'):
            raise ValueError('preferred_mode는 online 또는 offline입니다.')
        if 'grade' in fields and (type(fields['grade']) is not int or not 1 <= fields['grade'] <= 4):
            raise ValueError('grade는 1~4 정수입니다.')
        path = self._path(user_id)
        profile = {**self.get(user_id), **fields}
        fd, temporary = tempfile.mkstemp(dir=self.directory, prefix='.profile-', suffix='.tmp')
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump(profile, handle, ensure_ascii=False, indent=2)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return profile

    def forget(self, user_id: str) -> None:
        self._path(user_id).unlink(missing_ok=True)

    def context(self, user_id: str) -> str:
        return '저장 프로필 (현재 사용자의 명시적 요청을 우선):\n' + json.dumps(self.get(user_id), ensure_ascii=False)
