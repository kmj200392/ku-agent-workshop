from __future__ import annotations

import asyncio
import json
import sys
from contextlib import asynccontextmanager
from .config import ROOT


class MCPTools:
    def __init__(self, session, definitions: list[dict]):
        self.session = session
        self.definitions = definitions

    async def execute(self, name: str, arguments: dict) -> dict:
        if name not in {t['function']['name'] for t in self.definitions}:
            return {'error': 'unknown_tool', 'message': '서버가 제공한 도구가 아닙니다.'}
        result = await asyncio.wait_for(self.session.call_tool(name, arguments=arguments), timeout=10)
        if result.isError:
            return {'error': 'mcp_tool_error', 'message': 'MCP 서버가 도구 오류를 반환했습니다.'}
        structured = getattr(result, 'structuredContent', None)
        if isinstance(structured, dict):
            return structured
        for item in result.content:
            if getattr(item, 'type', None) == 'text':
                try:
                    decoded = json.loads(item.text)
                    if isinstance(decoded, dict):
                        return decoded
                except json.JSONDecodeError:
                    pass
        return {'text': '\n'.join(getattr(item, 'text', '') for item in result.content)}


@asynccontextmanager
async def connect_mcp(trace=None):
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
    except ImportError:
        raise RuntimeError('MCP 시연에는 python -m pip install -r requirements.txt가 필요합니다.') from None
    parameters = StdioServerParameters(command=sys.executable, args=[str(ROOT / 'mcp_server.py')])
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as session:
            await asyncio.wait_for(session.initialize(), timeout=15)
            listed = await asyncio.wait_for(session.list_tools(), timeout=10)
            definitions = [{'type': 'function', 'function': {
                'name': tool.name, 'description': tool.description or '', 'parameters': tool.inputSchema}}
                for tool in listed.tools]
            if trace:
                trace.add('mcp', '실제 MCP stdio 연결과 tools/list 결과', definitions)
            yield MCPTools(session, definitions)
