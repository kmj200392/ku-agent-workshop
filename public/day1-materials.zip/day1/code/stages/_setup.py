"""각 단계에서 공통으로 사용하는 실행 모드·경로 설정."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agent_workshop.api import SchoolModel
from agent_workshop.config import Settings
from agent_workshop.mock_model import TeachingModel
from agent_workshop.trace import Trace


def setup(stage):
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('mock', 'live'), default='mock')
    args = parser.parse_args()
    model = TeachingModel() if args.mode == 'mock' else SchoolModel(Settings.from_env())
    return model, Trace(args.mode, stage)
