from __future__ import annotations

import json
import re
from pathlib import Path
from .config import ROOT

DATA = ROOT / 'data'


def events() -> list[dict]:
    return json.loads((DATA / 'events.json').read_text(encoding='utf-8'))


def search_events(query: str) -> dict:
    """제목·태그를 검색합니다. 상세 조건은 get_event로 조회합니다."""
    q = query.casefold()
    terms = [w for w in ('python', 'javascript', '입문', '심화', '데이터', '검색', '진로', '웹') if w in q]
    matches = [e for e in events() if any(w in (e['title'] + ' '.join(e['tags'])).casefold() for w in terms)]
    return {'events': [{'id': e['id'], 'title': e['title']} for e in matches],
            'count': len(matches), 'source': 'events.json (수업용 가상 자료)'}


def get_event(event_id: str) -> dict:
    for event in events():
        if event['id'] == event_id:
            return event
    return {'error': 'not_found', 'message': '해당 행사 ID가 없습니다.'}


def policy_chunks() -> list[dict]:
    chunks = []
    for path in sorted((DATA / 'policies').glob('*.md')):
        text = path.read_text(encoding='utf-8')
        for section in text.split('\n## ')[1:]:
            heading, body = section.split('\n', 1)
            number = heading.split()[0]
            chunks.append({'source': f'{path.name}#{number}', 'heading': heading, 'text': body.strip()})
    return chunks


def search_policy(query: str, limit: int = 3) -> dict:
    """작은 자료를 위한 키워드 검색. 임베딩·벡터 DB를 사용하지 않습니다."""
    if not query.strip() or not 1 <= limit <= 5:
        raise ValueError('query는 빈 문자열일 수 없고 limit은 1~5입니다.')
    q = query.casefold()
    ids = re.findall(r'e-\d{3}', q)
    vocab = ('python', '입문', '심화', '1학년', '신청', '자격', '노트북', '준비물',
             '일정', '변경', '링크', '접속', '정원', '잔여', '참가비', '교통비', '수료증', '녹화본')
    terms = [word for word in vocab if word in q]
    ranked = []
    for chunk in policy_chunks():
        body = (chunk['heading'] + ' ' + chunk['text']).casefold()
        score = sum(8 for code in ids if code in body) + sum(1 for word in terms if word in body)
        if score:
            ranked.append({**chunk, 'score': score})
    ranked.sort(key=lambda x: (-x['score'], x['source']))
    return {'query': query, 'matches': ranked[:limit], 'method': 'keyword overlap, no embeddings'}
