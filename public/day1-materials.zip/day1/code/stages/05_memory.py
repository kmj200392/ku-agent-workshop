"""D13–D14: 명시적으로 저장한 프로필을 새 요청에서 읽습니다."""
import asyncio
from _setup import setup
from agent_workshop.config import ROOT
from agent_workshop.demos import messages
from agent_workshop.memory import ProfileStore
from agent_workshop.tools import LocalTools
from agent_workshop.loop import run_agent


async def main():
    model, trace = setup('05_memory')
    store = ProfileStore(ROOT / 'state')
    user = 'my_practice'
    # 사용자가 제공한 명시적 선택값입니다. 자동 정보 추출 예제가 아닙니다.
    store.update(user, {'grade': 1, 'preferred_mode': 'online'})
    request = '나에게 맞는 Python 입문 행사와 신청 규정 근거를 알려줘.'
    trace.add('memory_read', '저장한 프로필', store.get(user))
    await run_agent(model, LocalTools(), messages(request, store.context(user)), trace)
    trace.print()


asyncio.run(main())
