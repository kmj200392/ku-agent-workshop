from __future__ import annotations

import asyncio
from .knowledge import search_events, get_event, search_policy


def definition(name: str, description: str, properties: dict, required: list[str]) -> dict:
    return {'type': 'function', 'function': {'name': name, 'description': description,
            'parameters': {'type': 'object', 'properties': properties,
                           'required': required, 'additionalProperties': False}}}


TOOL_DEFINITIONS = [
    definition('search_events', '수업용 행사 목록을 제목·태그로 검색한다. 상세 조건은 get_event로 확인한다.',
               {'query': {'type': 'string', 'minLength': 1, 'maxLength': 500}}, ['query']),
    definition('get_event', '행사 ID로 일정·참가 형태·난이도·학년 조건을 조회한다.',
               {'event_id': {'type': 'string', 'minLength': 1, 'maxLength': 20}}, ['event_id']),
    definition('search_policy', '참가 자격·신청 규정을 검색하고 출처 ID와 문단을 반환한다.',
               {'query': {'type': 'string', 'minLength': 1, 'maxLength': 500},
                'limit': {'type': 'integer', 'minimum': 1, 'maximum': 5}}, ['query']),
]


class LocalTools:
    def __init__(self, names: tuple[str, ...] = ('search_events', 'get_event', 'search_policy')):
        self.definitions = [d for d in TOOL_DEFINITIONS if d['function']['name'] in names]
        self.functions = {'search_events': search_events, 'get_event': get_event, 'search_policy': search_policy}

    async def execute(self, name: str, arguments: dict) -> dict:
        spec = next((d['function'] for d in self.definitions if d['function']['name'] == name), None)
        if spec is None:
            return {'error': 'unknown_tool', 'message': '허용하지 않은 도구입니다.'}
        if not isinstance(arguments, dict):
            return {'error': 'invalid_arguments', 'message': '인자는 JSON object여야 합니다.'}
        schema = spec['parameters']
        if set(arguments) - set(schema['properties']) or set(schema['required']) - set(arguments):
            return {'error': 'invalid_arguments', 'message': '필수 필드 누락 또는 허용하지 않은 필드입니다.'}
        for key, value in arguments.items():
            rule = schema['properties'][key]
            if rule['type'] == 'string' and (not isinstance(value, str) or not value.strip() or len(value) > rule['maxLength']):
                return {'error': 'invalid_arguments', 'message': f'{key} 문자열을 확인하세요.'}
            if rule['type'] == 'integer' and (type(value) is not int or not rule['minimum'] <= value <= rule['maximum']):
                return {'error': 'invalid_arguments', 'message': f'{key} 정수 범위를 확인하세요.'}
        return await asyncio.to_thread(self.functions[name], **arguments)
