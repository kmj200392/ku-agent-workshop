"""D08–D09: 도구를 로컬 함수 대신 실제 MCP 서버에서 가져옵니다."""
import asyncio
from _setup import setup
from agent_workshop.demos import messages
from agent_workshop.mcp_bridge import connect_mcp
from agent_workshop.loop import run_agent


async def main():
    model, trace = setup('03_mcp')
    async with connect_mcp(trace) as tools:
        await run_agent(model, tools, messages('등록된 Python 행사 목록을 알려줘.'), trace)
    trace.print()


asyncio.run(main())
