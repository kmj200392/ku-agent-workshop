"""D05: 모델의 도구 요청을 프로그램이 한 번 실행합니다."""
import asyncio
import json
from _setup import setup
from agent_workshop.demos import messages
from agent_workshop.tools import LocalTools


async def main():
    model, trace = setup('01_tool_call')
    tools = LocalTools(('search_events',))
    response = await model.chat(messages('등록된 Python 행사 목록을 알려줘.'), tools.definitions)
    trace.add('model_output', '모델의 응답', response)
    requests = response['message'].get('tool_calls') or []
    if requests:
        request = requests[0]['function']
        try:
            arguments = json.loads(request['arguments'])
        except (json.JSONDecodeError, TypeError):
            arguments = None
        result = await tools.execute(request['name'], arguments)
        trace.add('tool_result', '프로그램이 실제로 함수를 실행한 결과', result)
    else:
        trace.add('notice', '도구 선택 없음', '모델이 도구를 요청하지 않았습니다. 요청과 도구 설명을 확인하세요.')
    trace.add('notice', '다음 단계', '결과를 모델에 다시 전달하고 반복하는 코드는 02_agent_loop에서 확인합니다.')
    trace.print()


asyncio.run(main())
