#!/usr/bin/env python3
"""강사용 로컬 시연 화면. python serve.py --mode mock (또는 live)."""
from __future__ import annotations

import argparse
import asyncio
import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from agent_workshop.config import ROOT
from agent_workshop.demos import DEMOS, run_demo


def make_server(mode: str, port: int = 8765):
    token = secrets.token_urlsafe(24)
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass

        def send(self, code, body, content_type='application/json; charset=utf-8'):
            data = json.dumps(body, ensure_ascii=False).encode() if isinstance(body, (dict, list)) else body.encode()
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(data)

        def valid_host(self):
            return self.headers.get('Host', '') in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}')

        def do_GET(self):
            if not self.valid_host():
                return self.send(403, {'error': '로컬 주소로 접속하세요.'})
            if self.path == '/':
                page = (ROOT / 'viewer.html').read_text(encoding='utf-8')
                return self.send(200, page.replace('__TOKEN__', token).replace('__MODE__', mode), 'text/html; charset=utf-8')
            if self.path == '/api/demos':
                return self.send(200, [{'id': k, 'title': v[0], 'slide': v[1]} for k, v in DEMOS.items()])
            return self.send(404, {'error': '없는 경로입니다.'})

        def do_POST(self):
            if not self.valid_host() or self.headers.get('X-Demo-Token') != token:
                return self.send(403, {'error': '이 시연 페이지에서 실행하세요.'})
            if self.path != '/api/run':
                return self.send(404, {'error': '없는 경로입니다.'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 1 <= length <= 1024:
                    raise ValueError
                payload = json.loads(self.rfile.read(length))
                demo_id = payload['demo']
                if demo_id not in DEMOS:
                    raise ValueError
            except (ValueError, KeyError, TypeError):
                return self.send(400, {'error': 'D01~D14 중 하나를 선택하세요.'})
            if not lock.acquire(blocking=False):
                return self.send(409, {'error': '이전 시연이 실행 중입니다.'})
            try:
                trace = asyncio.run(run_demo(demo_id, mode))
                trace.save(ROOT / 'outputs' / mode / f'{demo_id}.json')
                self.send(200, trace.as_dict())
            except Exception as exc:
                message = str(exc) if isinstance(exc, (ValueError, RuntimeError)) else type(exc).__name__ + ': 의존성과 실행 환경을 확인하세요.'
                self.send(500, {'error': message})
            finally:
                lock.release()

    return ThreadingHTTPServer(('127.0.0.1', port), Handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('mock', 'live'), default='mock')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    server = make_server(args.mode, args.port)
    print(f'http://127.0.0.1:{server.server_port}  [{args.mode}]', flush=True)
    print('mock: 교육용 규칙 응답 / live: 학교 API 호출로 개인 크레딧 사용. 종료: Ctrl+C', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
