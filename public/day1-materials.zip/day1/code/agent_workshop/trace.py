from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Trace:
    mode: str
    demo: str
    events: list[dict[str, Any]] = field(default_factory=list)

    def add(self, kind: str, label: str, data: Any) -> None:
        self.events.append({'seq': len(self.events) + 1, 'kind': kind,
                            'label': label, 'data': copy.deepcopy(data)})

    def as_dict(self) -> dict:
        return {'demo': self.demo, 'mode': self.mode,
                'disclosure': ('교육용 모의 모델. 응답 선택은 규칙으로 재현하며 실제 LLM 추론이 아닙니다.'
                               if self.mode == 'mock' else '학교 API 실호출 모드. 개인 크레딧을 사용합니다.'),
                'events': self.events}

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.as_dict(), ensure_ascii=False, indent=2), encoding='utf-8')

    def print(self) -> None:
        print(f'\n[{self.demo}] {self.as_dict()["disclosure"]}')
        for event in self.events:
            print(f'\n{event["seq"]:02d}. {event["label"]} [{event["kind"]}]')
            value = event['data']
            print(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2))
