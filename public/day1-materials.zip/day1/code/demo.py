#!/usr/bin/env python3
"""python demo.py D06 --mode mock / --mode live"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from agent_workshop.api import SchoolModel, ModelError
from agent_workshop.config import ROOT, Settings
from agent_workshop.demos import DEMOS, run_demo


async def main(args) -> int:
    if args.list:
        for key, (title, slide) in DEMOS.items():
            print(f'{key}  슬라이드 {slide:02d}  {title}')
        return 0
    if args.list_models:
        data = await SchoolModel(Settings.from_env()).list_models()
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    ids = list(DEMOS) if args.all else [args.demo]
    if not ids[0]:
        raise ValueError('D01~D14 또는 --all을 지정하세요. 목록: --list')
    failures = []
    for demo_id in ids:
        try:
            trace = await run_demo(demo_id, args.mode, args.state_dir)
            failed = any(e['kind'] == 'stop' and e['data']['reason'] in ('model_error', 'invalid_response') for e in trace.events)
            if failed:
                failures.append(demo_id)
            if not args.quiet:
                trace.print()
            if args.output:
                trace.save(args.output / f'{demo_id}.json')
            elif args.all:
                trace.save(ROOT / 'outputs' / args.mode / f'{demo_id}.json')
            print(f'{demo_id}: {"FAILED" if failed else "완료"} ({args.mode})')
        except Exception as exc:
            failures.append(demo_id)
            # 예외의 타입/짧은 설명만 출력합니다. API 헤더와 환경변수는 출력하지 않습니다.
            if isinstance(exc, (ValueError, RuntimeError, ModelError)):
                print(f'{demo_id}: {exc}', file=sys.stderr)
            else:
                print(f'{demo_id}: {type(exc).__name__}. 의존성과 실행 환경을 확인하세요.', file=sys.stderr)
    return 1 if failures else 0


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('demo', nargs='?', choices=DEMOS)
    parser.add_argument('--mode', choices=('mock', 'live'), default='mock')
    parser.add_argument('--all', action='store_true', help='모든 시연 실행. live는 여러 API 호출로 크레딧 사용')
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--list-models', action='store_true', help='설정한 개인 키로 학교 모델 목록 조회')
    parser.add_argument('--output', type=Path, help='JSON 실행 기록을 저장할 폴더')
    parser.add_argument('--state-dir', type=Path)
    parser.add_argument('--quiet', action='store_true')
    args = parser.parse_args()
    try:
        raise SystemExit(asyncio.run(main(args)))
    except (ValueError, ModelError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    cli()
