# AI Agent 1일차 시연 코드

설명과 시연을 번갈아 진행하는 2026-10-28 수업용 코드입니다. 모든 행사·규정·사용자 정보는 가상 자료입니다.

## 빠른 시작

Python 3.10 이상이 필요합니다. 제작 환경은 Python 3.12입니다. macOS 기본 Python 3.9에서는 MCP 의존성을 설치할 수 없으므로 Python 3.12 등 별도 Python을 사용하세요.

압축을 풀고 **이 README가 있는 `code` 폴더**를 터미널에서 엽니다.

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python serve.py --mode mock
```

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe serve.py --mode mock
```

브라우저에서 [시연 화면](http://127.0.0.1:8765)을 엽니다. 왼쪽에서 D01–D14를 고르고 **시연 실행**을 누릅니다. 종료는 터미널에서 Ctrl+C입니다. 화면에는 모델 입력, 도구 요청, 실행 결과, 최종 답변이 표시됩니다. 모델 입력·출력은 접힌 항목을 눌러 펼칩니다.

각 시연의 마지막 실행 결과와 마지막으로 선택한 시연은 같은 브라우저·주소에 저장됩니다. 다른 시연으로 이동하거나 페이지를 다시 열어도 결과를 복원하며, **다시 실행**을 눌러 새 결과를 받으면 해당 시연의 기록을 갱신합니다. 복원할 때 API를 호출하지 않습니다. mock과 live 기록은 따로 보관하며, 브라우저의 사이트 데이터를 삭제하면 이 저장 내용도 지워집니다.

`serve.py`는 강사 컴퓨터에서 쓰는 로컬 시연 화면입니다. 2일차 학생 코드 제출·평가 대시보드는 별도 구현 대상입니다.

## 두 실행 모드

| 모드 | 모델 응답 | 도구·검색·기억 | MCP | 용도 |
| --- | --- | --- | --- | --- |
| `mock` | 교육용 규칙으로 재현. 실제 LLM 추론 아님 | 실제 Python 코드 실행 | 실제 stdio 서버 통신 | 키 없는 리허설과 연결 장애 시 설명 |
| `live` | 학교 API 실호출 | 실제 Python 코드 실행 | 실제 stdio 서버 통신 | 실제 모델 반응과 프롬프트 실험 |

모의 모델은 수업의 정해진 요청을 설명하기 위한 규칙입니다. 임의 아이디어를 구현하거나 모델 성능을 평가할 때는 live를 사용하세요. 모의 결과를 실제 모델 실험 결과로 소개하지 않습니다. D07의 반복 제한은 live에서도 의도적으로 모의 모델을 쓰는 고장 주입 구간이며 화면에 표시합니다. D08·D10은 모델을 호출하지 않습니다.

## 학교 API 설정

1. [학교 개발자 화면](https://llm.korea.ac.kr/dashboard/developers)에서 개인 API 키와 접근 가능한 모델 ID를 확인합니다. 키를 채팅·코드·슬라이드에 붙이지 않습니다.
2. `.env.example`을 같은 폴더의 `.env`로 복사합니다.
3. `.env`의 `KU_API_KEY`, `KU_MODEL`을 채웁니다. 키가 있는 `.env`는 배포하지 않습니다.
4. 활성화한 가상환경에서 다음 순서로 확인합니다.

```bash
python demo.py --list-models
python demo.py D03 --mode live
python demo.py D05 --mode live
python demo.py D06 --mode live
python serve.py --mode live
```

웹 화면을 live로 바꾸려면 기존 mock 서버를 Ctrl+C로 종료하고 다시 시작합니다. 이미 열려 있는 페이지를 새로고침해 상단 모드를 확인합니다. `--port 8766`처럼 다른 포트도 사용할 수 있습니다.

Gateway의 Chat Completions 주소는 `https://api.baze.co/v1/gateway/chat/completions/`이고 Bearer 키로 인증합니다. 모델 이름을 임의로 기본값에 넣지 않았습니다. 모델 목록의 ID를 확인하고 **Tool Calling을 지원하는 모델**을 선택하세요.

실제 개인 키가 제공되지 않아 이 배포본에서 학교 API의 인증·추론·크레딧 차감을 실검증하지 않았습니다. 로컬 HTTP 대역으로 요청 경로, 인증 헤더, 오류 처리와 응답 형식을 테스트했습니다. 수업 전 위 3개 실호출과 D14를 리허설해야 합니다.

### 토큰과 오류

- `.env.example`의 출력 한도 900은 짧은 응답 예제 시작값입니다. 모든 모델에 충분한 값이 아닙니다.
- 추론 모델은 내부 추론 토큰도 예산에 포함할 수 있습니다. 빈 응답이나 `length` 종료가 나면 [학교 Chat Completions 문서](https://docs.factchat.kr/docs/korea-seoul/api-gateway/reference/chat-completions)에 따라 `KU_MAX_OUTPUT_TOKENS`를 늘리고 비용을 확인하세요.
- 필요한 모델에서는 `KU_TOKEN_PARAMETER=max_completion_tokens`를 사용합니다.
- 한 시연에서 여러 모델 호출이 발생합니다. `--all --mode live`는 전체 시연에 크레딧을 사용하므로 기본 리허설은 mock으로 합니다.
- 모델 호출 오류를 자동 재시도하지 않습니다. HTTP 401·403은 키·권한, 429는 제한·크레딧, 400은 요청 파라미터를 점검합니다.
- 로컬 도구는 최대 10초, 모델 HTTP는 기본 40초, 루프는 기본 6단계·도구 요청 8회로 제한합니다. 이 한도는 단일 루프 기준이며 D13처럼 여러 루프가 있는 시연의 총량과 다릅니다.

## CLI와 단계별 파일

```bash
python demo.py --list
python demo.py D06 --mode mock
python demo.py --all --mode mock --quiet
python stages/00_model.py --mode mock
python stages/02_agent_loop.py --mode live
```

| 파일 | 읽고 바꿔볼 부분 |
| --- | --- |
| `stages/00_model.py` | 지시문과 질문 |
| `stages/01_tool_call.py` | 도구 요청을 함수 실행으로 연결 |
| `stages/02_agent_loop.py` | 도구 선택과 종료 한도 |
| `stages/03_mcp.py` | 실제 MCP 도구로 바꾸는 연결부 |
| `stages/04_rag.py` | 문서 검색 결과를 모델 입력에 전달 |
| `stages/05_memory.py` | 사용자 프로필 저장과 재사용 |
| `agent_workshop/loop.py` | 반복·인자 검증·도구 오류·종료 처리 |
| `agent_workshop/knowledge.py` | 작은 자료의 키워드 검색 |
| `agent_workshop/memory.py` | 사용자별 JSON 저장·조회·삭제 |
| `mcp_server.py` | SDK로 만든 실제 도구 서버 |

모델 호출·도구·RAG·Memory 코드는 표준 라이브러리 위주이며 MCP 단계에 SDK가 필요합니다. 코드의 MCP API는 1.26.0으로 고정했습니다. 최신 2.x SDK 예제와 섞어 쓰지 마세요. 전체 테스트가 필요하면 requirements를 먼저 설치합니다.

## 수업 시연 대응표

| ID | 슬라이드 | 내용 |
| --- | --- | --- |
| D01 | 03 | 같은 질문, 모델 단독과 도구 조회 비교 |
| D02 | 05 | 실행 기록 읽기 |
| D03 | 07 | 최소 API 호출 |
| D04 | 09 | 지시문 변경 |
| D05 | 11 | Tool Calling과 함수 실행 |
| D06 | 13 | 목록 다음 상세 조회 |
| D07 | 15 | 결과 없음, 단계 한도, 인자 검증 |
| D08 | 18 | MCP 도구 목록 |
| D09 | 20 | MCP 도구 실행 |
| D10 | 22 | 규정 문단 검색 |
| D11 | 24 | 근거를 넣어 응답 생성 |
| D12 | 26 | messages 초기화 |
| D13 | 28 | 프로필 저장·새 대화·일회성 요청 |
| D14 | 30 | 도구·검색·기억 통합 |

D08에서 얻은 목록과 D10의 검색 결과를 설명한 뒤 다음 시연으로 넘어갑니다. 각 시연은 독립 실행 가능하게 준비 상태를 다시 구성하므로 중간 번호부터 재개할 수 있습니다. D13·D14는 각각 `demo_d13`, `demo_d14` 가상 프로필만 초기화합니다.

## 실행 기록과 기억

- 웹에서 실행하면 `outputs/mock/` 또는 `outputs/live/`에 JSON 기록을 저장합니다.
- CLI의 `--output 폴더`로 저장 위치를 지정할 수 있습니다.
- 기록은 요청·도구·최종 답변을 포함합니다. 비공개 모델 추론이나 인증 헤더를 기록하지 않습니다.
- 배포용 `example_traces/`는 **교육용 모의 실행 기록**입니다. 실제 API 기록이 아닙니다.
- `state/`의 프로필 JSON은 프로그램을 종료해도 남습니다. 실제 서비스의 인증·동시성·암호화 계층은 이 입문 예제 범위 밖입니다.
- 저장은 사용자가 제공한 명시적 선택값을 앱에서 처리합니다. 자유 문장으로부터 자동으로 기억을 추출하는 구현은 포함하지 않았습니다.

## 검증 실행

```bash
python -m unittest discover -s tests -v
```

테스트는 고정된 행사·규정 사례, 사용자 간 기억 분리와 지속성, 도구 입력 검증, 호출 제한, 시간 초과, 실제 MCP 통신, 로컬 HTTP 대역의 API 계약을 확인합니다. 학교 API 실호출 테스트와는 구분합니다.

## 자료 수정과 배포

수업 뒤 자신의 아이디어로 바꿔보는 것은 자율이며 제출 과제가 아닙니다. `.env`, `.venv`, `state`, 실제 개인 데이터가 든 `outputs`는 공유하지 않습니다. 강의의 가상 fixture와 코드만 복사해 시작하세요.

공식 참고: [학교 API 인증](https://docs.factchat.kr/docs/korea-seoul/api-gateway/getting-started/authentication), [MCP Python SDK 1.26.0](https://github.com/modelcontextprotocol/python-sdk/tree/v1.26.0), [MCP 구조](https://modelcontextprotocol.io/docs/learn/architecture), [RAG](https://docs.langchain.com/oss/python/deepagents/retrieval), [Memory](https://docs.langchain.com/oss/python/concepts/memory).
